public interface Cadastro {
    void cadastrar();
    void editar();
    void exibir();
}
